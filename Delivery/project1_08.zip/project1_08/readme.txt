122B, Group 8, Project 1 README:

1. the zip contains createtable.sql, createtable_08.sql(same as createtable.sql), data.sql, and three java files(Main, Login, Utility);
2. Compile instructions: javac Main.java
3. Run the program: java -cp (path of JDBC driver) Main
