import java.sql.*;

public class Utility{

	public static Connection connection = null;

}